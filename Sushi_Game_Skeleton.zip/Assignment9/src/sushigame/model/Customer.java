package sushigame.model;

import comp401.sushi.Plate;

public interface Customer {

	boolean consumesPlate(Plate p);
}
