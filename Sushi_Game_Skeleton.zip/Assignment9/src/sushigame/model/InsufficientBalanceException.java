package sushigame.model;


public class InsufficientBalanceException extends Exception {

}
