package sushigame.controller;

import sushigame.model.BeltObserver;

public interface ChefController extends BeltObserver {

}
