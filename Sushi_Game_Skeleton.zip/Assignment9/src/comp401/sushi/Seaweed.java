package comp401.sushi;

public class Seaweed extends IngredientImpl {

	public Seaweed() {
		super("seaweed", 2.95, 113, true, false, false);
	}
}
