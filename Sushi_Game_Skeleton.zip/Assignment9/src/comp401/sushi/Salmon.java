package comp401.sushi;

public class Salmon extends IngredientImpl {

	public Salmon() {
		super("salmon", 0.72, 56, false, false, false);
	}
}
